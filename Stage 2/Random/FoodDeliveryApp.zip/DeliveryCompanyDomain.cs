using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDeliveryApp          //Do not change the namespace name
{
/* Use Data Annotations for the below work */

    //Add Company_Tb as table name
    [Table("Company_Tb")]
    public class DeliveryCompanyDomain         //Do not change the class name
    {
        //Make Company_Registration_Code as primary key
        [Key]
        public int Company_Registration_Code { get; set; }
        
	//Company name is required [manditory]
	    [Required(AllowEmptyStrings=false)]
        public string Company_Name { get; set; }
        public DateTime Registration_Date { get; set; }
    }
}
