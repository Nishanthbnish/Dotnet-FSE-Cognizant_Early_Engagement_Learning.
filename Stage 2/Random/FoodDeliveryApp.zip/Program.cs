using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDeliveryApp        //Do not change the namespace name
{ 
    class Program               //Do not change the class name
    {
        static void Main(string[] args)
        {
            //fill code here
            DeliveryContext con=new DeliveryContext();
            DeliveryRepository repos = new DeliveryRepository(con);
            DeliveryCompanyDomain db = new DeliveryCompanyDomain();
            AgentDomain ab = new AgentDomain();
            while(true)
            {
                Console.WriteLine("Enter Company Name and Registration Date information separated by comma (,):");
                string str=Console.ReadLine();
                db.Company_Name=(str.Split(','))[0];
                db.Registration_Date=Convert.ToDateTime((str.Split(','))[1])
                if(repos.AddCompany(db)==1)
                {
                    Console.WriteLine("New Company Inserted Successfully ");
                }
                else
                {
                    Console.WriteLine("Data Insertion Failed");
                }
                Console.WriteLine("Do you want to add another agent(yes/no)?");
                string s = Console.ReadLine();
                if(s=="yes")
                {
                    continue;
                }
                else
                {
                    break;
                }
            }
            while(true)
            {
                Console.WriteLine("Enter Agent Name and Mobile Number Details separated by comma (,):");
                string str=Console.ReadLine();
                ab.Agent_Name=(str.Split(','))[0];
                ab.Mobile_Number=Convert.ToInt64((str.Split(','))[1])
                if(repos.AddAgent(ab)==1)
                {
                    Console.WriteLine("New Agent Inserted Successfully ");
                }
                else
                {
                    Console.WriteLine("Data Insertion Failed");
                }
                Console.WriteLine("Do you want to add another agent(yes/no)?");
                string s = Console.ReadLine();
                if(s=="yes")
                {
                    continue;
                }
                else
                {
                    break;
                }
            }
        }
    }
}
