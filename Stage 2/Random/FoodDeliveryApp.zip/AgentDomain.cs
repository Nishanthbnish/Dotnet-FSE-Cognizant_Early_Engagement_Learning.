using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace FoodDeliveryApp                   //Do not change the namespace name
{
/* Use Data Annotations for the below work */

    //Add Agent_Tb as table name
    [Table("Agent_Tb")]
    public class AgentDomain              //Do not change the class name
    {
        //Make Id as Primary Key
        [Key]
        public int Id { get; set; }

        //Agent name is required
        //  [Required(AllowEmptyStrings=false)]
        [Required]
        public string Agent_Name { get; set; }
        public Int64 Mobile_Number { get; set; }
    }
}
