using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDeliveryApp          //Do not change the namespace name
{
    public class DeliveryRepository              //Do not change the class name
    {
        // private DeliveryContext context;

        // public DeliveryRepository(DeliveryContext context)
        // {
        //     //fill code here
        //     this.context=context;
        // }

        public int AddCompany(DeliveryCompanyDomain company)
        {
            //fill code here
            var context= new  DeliveryContext();
            context.Companies.Add(company);
            int add=context.SaveChanges();
            if(add>0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        public int AddAgent(AgentDomain agent)
        {
           //fill code here
           var context= new  DeliveryContext();
            context.Agents.Add(agent);
            int add=context.SaveChanges();
            if(add>0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        public IList<DeliveryCompanyDomain> DisplayAllCompanies()
        {
            //fill code here
            var context= new  DeliveryContext();
            var query=(from a in context.Companies
                      select a).ToList<DeliveryCompanyDomain>();
            return query;
            
        }

        public IList<AgentDomain> DisplayAllAgents()
            {
           	 //fill code here
           	 var context= new  DeliveryContext();
            var query=(from a in context.Agents
                      select a).ToList<AgentDomain>();
            return query;
            }
    }
}
