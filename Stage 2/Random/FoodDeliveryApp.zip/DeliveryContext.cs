using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDeliveryApp                //Do not change the namespace name
{
    public class DeliveryContext:DbContext                  //Do not change the class name
    { 
 	//Do NOT change the context name 'DeliveryContext'
        public DeliveryContext():base("name=DeliveryDbString")
        {

        }

         //Implement property for 'Companies' and 'Agents' with required 'DbSet' declaration
         public virtual DbSet<DeliveryCompanyDomain> Companies{get; set;}
         public virtual DbSet<AgentDomain> Agents{get; set;}
    }
}
